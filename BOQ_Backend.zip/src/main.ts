import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
const ip = require("ip")
const host = ip.address()
const apiport = process.env.API_PORT || 3000
async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const config = new DocumentBuilder()
  .setTitle('T247BoqNestjs')
  .setDescription('T247BoqNestjs')
  .setVersion('1.0')
  .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'jwt') 
  .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);
  app.enableCors();
  await app.listen(apiport,host);
  console.log(`Server is listening on  http://${host}:${apiport}/api`);
}
bootstrap();
