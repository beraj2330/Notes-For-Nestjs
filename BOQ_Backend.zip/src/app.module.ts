import { Module } from '@nestjs/common';
import { TenderBOQModule } from './TenderBOQ/TenderBOQModule.module';
import * as dotenv from 'dotenv';
import { ConfigModule } from '@nestjs/config';
import { DatabasePgModule } from './database/databasePg.module';
import { QueryHandlerModule } from './TenderBOQ/middlewares/queryHandlerSQL.module';
dotenv.config();
@Module({
  imports: [ ConfigModule.forRoot(),QueryHandlerModule,TenderBOQModule],
})
export class AppModule {}
