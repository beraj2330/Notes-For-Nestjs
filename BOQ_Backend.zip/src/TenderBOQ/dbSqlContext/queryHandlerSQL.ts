import { Injectable } from "@nestjs/common";
import { ApiResponse } from "../helper/apiResponse.middleware"; // Adjust the import path accordingly
import { DbSqlService } from "./dbSqlContext";
import { ServerError } from "../helper/apiStatusCode";

@Injectable()
export class QueryHandlerService {
  constructor(
    private readonly dbSqlService: DbSqlService // Inject DbSqlService
    // private readonly logger: LoggerService
  ) { }

  async queryHandler(
    query: string,
    params: any[] = [],
    outParams: any[] = []
  ): Promise<any> {
    try {
      const result = await this.dbSqlService.callSPWithOutParam(
        query,
        params,
        outParams
      );

      if (result.rows && result.rows.length > 0) {
        return result;
      } else {
        return result;
      }
    } catch (error) {
      console.log(error, "query handler")
      const errorData = {
        ...{
          query: JSON.stringify(query),
          params: JSON.stringify(params),
          error: error,
        },
      }
      if (errorData?.error?.Message?.stack != "") {
        const getMessage = errorData?.error?.Message?.stack?.split("\n")
        const errMsg = getMessage[0]?.replace("Error: ", "")
        return ApiResponse(ServerError, errMsg, false, [], 0, false)
      } else {
        return ApiResponse(ServerError, error, false, [], 0, false)
      }
    }
  }
}
