import { Module } from "@nestjs/common";
import * as mssql from "mssql";
import { DbSqlService } from "./dbSqlContext";

@Module({
  providers: [
    {
      provide: "MSSQL_POOL",
      useFactory: async () => {
        const pool = new mssql.ConnectionPool({
          server: process.env.DB_SQL_HOST,
          database: process.env.DB_SQL_DATABASE,
          user: process.env.DB_SQL_USERNAME,
          password: process.env.DB_SQL_PASSWORD,
          port: parseInt(process.env.DB_SQL_PORT),
          driver: "SQL Server",
          pool: {
            max: 1000,
            min: 0,
            idleTimeoutMillis: 3000000,
          },
          options: {
            encrypt: false,
            trustServerCertificate: true,
            enableArithAbort: false,
          },
        });

        try {
          await pool.connect();
          console.log("Database connected successfully");
          return pool;
        } catch (error) {
          console.error("Error connecting to MSSQL:", error);
          throw error;
        }
      },
    },
    DbSqlService
  ],
  exports: ["MSSQL_POOL",DbSqlService], // Export the MSSQL_POOL provider
})
export class DbSqlModule {}
