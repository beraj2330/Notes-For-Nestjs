import { Injectable, Inject } from "@nestjs/common";
import * as sql from "mssql";
import { ApiResponse } from "../helper/apiResponse.middleware";
@Injectable()
export class DbSqlService {
  constructor(
    @Inject("MSSQL_POOL") private readonly sqlDbPool: sql.ConnectionPool // Inject the pool here
  ) {}

  // Ensure connection pool is connected
  private async ensureConnection(): Promise<void> {
    try {
      console.log("Checking if SQL pool is connected or connecting...");
      if (!this.sqlDbPool.connected && !this.sqlDbPool.connecting) {
        console.log("SQL pool is not connected. Establishing connection...");
        await this.sqlDbPool.connect();
        console.log("SQL pool connected successfully.");
      } else if (this.sqlDbPool.connected) {
        console.log("SQL pool is already connected.");
      } else if (this.sqlDbPool.connecting) {
        console.log("SQL pool is already in the process of connecting.");
      }
    } catch (error) {
      console.error("Error while connecting to SQL pool:", error);
      throw new Error("SQL connection failed.");
    }
  }

  // Call stored procedure without parameters
  async callSPWithOutParam(
    spName: string,
    inputParams: any[] = [],
    outputParams: any[] = []
  ): Promise<any> {
    console.log(`Executing stored procedure: ${spName}`);
    // console.log("Input Params:", inputParams);
    // console.log("Output Params:", outputParams);
    
    try {
      await this.ensureConnection(); // Ensure connection is established

      const request = this.sqlDbPool.request();

      // Set input parameters dynamically
      inputParams.forEach((param) => {
        const { name, type, value } = param;
        if (name && type) {
          request.input(name, type, value);
          console.log(`Input param set: Name=${name}, Type=${type}, Value=${value}`);
        } else {
          console.warn(`Skipping invalid input param: ${JSON.stringify(param)}`);
        }
      });

      // Set output parameters dynamically
      outputParams.forEach((param) => {
        const { name, type } = param;
        if (name && type) {
          request.output(name, type);
          console.log(`Output param set: Name=, Type=`);
        } else {
          console.warn(`Skipping invalid output param: ${JSON.stringify(param)}`);
        }
      });

      const result: sql.IProcedureResult<any> = await request.execute(spName);
      console.log("Stored procedure executed successfully.");
      
      const data =
        outputParams.length > 0 ? [result.output] : result.recordset || [];
      
      return ApiResponse(200, "success", true, data, data.length, true);
    } catch (error) {
      console.error("Error executing stored procedure:", error);
      throw ApiResponse(500, error.message, false, [], 0, false);
    }
  }

  // Call query without parameters
  async callQueryWithOutParam(
    query: string,
    inputParams: any[] = [],
    outputParams: any[] = []
  ): Promise<any> {
    console.log(`Executing query: ${query}`);
    console.log("Input Params:", inputParams);
    console.log("Output Params:", outputParams);

    try {
      await this.ensureConnection(); // Ensure connection is established

      const request = this.sqlDbPool.request();

      // Set input parameters dynamically
      inputParams.forEach((param) => {
        const { name, type, value } = param;
        if (name && type) {
          request.input(name, type, value);
          console.log(`Input param set: Name=${name}, Type=${type}, Value=${value}`);
        } else {
          console.warn(`Skipping invalid input param: ${JSON.stringify(param)}`);
        }
      });

      // Set output parameters dynamically
      outputParams.forEach((param) => {
        const { name, type } = param;
        if (name && type) {
          request.output(name, type);
          console.log(`Output param set: Name=${name}, Type=${type}`);
        } else {
          console.warn(`Skipping invalid output param: ${JSON.stringify(param)}`);
        }
      });

      const result = await request.query(query);
      console.log("Query executed successfully.");
      
      const data =
        outputParams.length > 0 ? [result.output] : result.recordset || [];
      
      console.log("Query result data:");
      return ApiResponse(200, "success", true, data, data.length, true);
    } catch (error) {
      console.error("Error executing query:", error);
      throw ApiResponse(500, error.message, false, [], 0, false);
    }
  }
}
