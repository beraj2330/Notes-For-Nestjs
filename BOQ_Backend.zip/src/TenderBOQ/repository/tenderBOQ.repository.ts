import { Injectable } from '@nestjs/common';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
import { DateUtilsService } from '../helper/dateHelper';
import { tenderBOQService } from '../service/tenderBOQ.service';
@Injectable()
export class tenderBOQRepository {

  constructor(
    private readonly tenderBOQService: tenderBOQService,
    private readonly loggerService: LoggerService,
    private readonly dateUtilsService: DateUtilsService,
  ) { }

  async getOneBOQTender(userId: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'AssigendTo', type: sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.tenderBOQService.getOneBOQTender(inputParams, outputParams); // Adjust method call
      const dateconvert = () => {
        return result.Data.map((res: any) => ({
          ...res,
          SubmissionDate: this.dateUtilsService.dateToDDMMYYYY(res?.SubmissionDate),
        }));
      };
      const data = dateconvert() as any;
      return ApiResponse(Success, 'Success', true, data, result?.Data.length, false);
    } catch (error) {
      this.loggerService.error("getone_tender_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async updateTenderBOQ(tenderBOQUpdateDto: any, userId: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'Boqid', type: sql.Int, value:  parseInt(tenderBOQUpdateDto.Boqid, 10) },
        { name: 'ItemDescription', type: sql.VarChar, value: tenderBOQUpdateDto.ItemDescription },
        { name: 'ItemCode', type: sql.VarChar, value: tenderBOQUpdateDto.ItemCode },
        { name: 'Quantity', type: sql.VarChar, value: tenderBOQUpdateDto.Quantity },
        { name: 'Unit', type: sql.Int, value: tenderBOQUpdateDto.Unit },
        { name: 'Brand', type: sql.Int, value: tenderBOQUpdateDto.Brand },
        { name: 'EstimatedRate', type: sql.VarChar, value: String(tenderBOQUpdateDto.EstimatedRate) },
        { name: 'TotalAmount', type: sql.Int, value: tenderBOQUpdateDto.TotalAmount },
        { name: 'AdditionalValue1', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue1 },
        { name: 'AdditionalValue2', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue2 },
        { name: 'AdditionalValue3', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue3 },
        { name: 'AdditionalValue4', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue4 },
        { name: 'AdditionalValue5', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue5 },
        { name: 'AdditionalValue6', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue6 },
        { name: 'AdditionalValue7', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue7 },
        { name: 'AdditionalValue8', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue8 },
        { name: 'AdditionalValue9', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue9 },
        { name: 'AdditionalValue10', type: sql.VarChar, value: tenderBOQUpdateDto.AdditionalValue10 },
        { name: 'ModifyBy', type: sql.Int, value: userId },
        { name: 'Model', type: sql.VarChar, value: tenderBOQUpdateDto.Model },
        { name: 'Specification', type: sql.VarChar, value: tenderBOQUpdateDto.Specification },
      ];
      const outputParams = []
      const result = await this.tenderBOQService.boqTenderUpdate(inputParams, outputParams);

      if (result.Success) {
        if (result.Data[0].status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("tender_boq_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("tender_boq_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
  async holdTenderBOQ(tenderBOQUpdateDto: any, userId: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'Boqid', type: sql.Int, value: tenderBOQUpdateDto.Boqid },
        { name: 'Comments', type: sql.VarChar, value: tenderBOQUpdateDto.Comments },
        { name: 'OnHoldby', type: sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.tenderBOQService.boqTenderHold(inputParams, outputParams);

      if (result.Success) {
        return ApiResponse(Success, "Data Hold successfully.", true, result.Data, result.Data.length);
      } else {
        this.loggerService.error("hold_tender_boq_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("hold_tender_boq_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
  async TenderSearch(tenderSearchDto: any, userId: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'Tenderid', type: sql.VarChar, value: tenderSearchDto.Tenderid },
        { name: 'TenderNumber', type: sql.VarChar, value: tenderSearchDto.TenderNumber },
        { name: 'OrganizationId', type: sql.VarChar, value: (tenderSearchDto.OrganizationId=="0" || tenderSearchDto.OrganizationId=="null")? "":tenderSearchDto.OrganizationId },
        { name: 'ModifiedDateTo', type: sql.VarChar, value: tenderSearchDto.CreatedDateTo || null },
        { name: 'ModifiedDateFrom', type: sql.VarChar, value: tenderSearchDto.CreatedDateFrom || null },
        { name: 'RequirementWorkBrief', type: sql.VarChar, value: tenderSearchDto.Brief },
        { name: 'AssignBy', type: sql.VarChar, value: tenderSearchDto.AssignBy=="0"? String(userId): tenderSearchDto.AssignBy},
        { name: 'OnHold', type: sql.Bit, value: tenderSearchDto.OnHold }
      ];
      const outputParams = []
      const result = await this.tenderBOQService.tenderSearch(inputParams, outputParams);

      if (result.Success) {
        return ApiResponse(Success, "Success", true, result.Data, result.Data.length);
      } else {
        this.loggerService.error("tender_search_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("tender_search_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async boqGetByIdTender(Boqid: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'Boqid', type: sql.Int, value: Boqid },
      ];
      const outputParams = []
      const result = await this.tenderBOQService.boqGetByIdTender(inputParams,outputParams);
      const dateconvert = () => {
        return result.Data.map((res: any) => ({
          ...res,
          SubmissionDate: this.dateUtilsService.dateToDDMMYYYY(res?.SubmissionDate),
        }));
      };
      const data = dateconvert() as any;
      return ApiResponse(Success, 'Success', true, data, result?.Data.length, false);
    } catch (error) {
      this.loggerService.error("boqGetByIdTender_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
}
