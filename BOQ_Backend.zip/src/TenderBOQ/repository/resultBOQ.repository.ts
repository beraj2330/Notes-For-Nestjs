import { Injectable } from '@nestjs/common';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
import { resultBOQService } from '../service/resultBOQ.service';
@Injectable()
export class resultBOQRepository {

  constructor(
    private readonly resultBOQService: resultBOQService,
    private readonly loggerService: LoggerService,
    ) {}

  async getOneBOQResult(userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'AssigendTo', type: sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.resultBOQService.getOneBOQResult(inputParams,outputParams); // Adjust method call
     return result
    } catch (error) {
      this.loggerService.error("getone_result_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async boqGetBidder(boqItemId: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'Boqitemid', type: sql.Int, value: boqItemId },
      ];
      const outputParams = []
      const result = await this.resultBOQService.boqGetBidder(inputParams,outputParams);
      return result
    } catch (error) {
      this.loggerService.error("boq_get_bidder_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async updateItemBOQ(itemBOQUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'BoqItemId', type:sql.Int, value: parseInt(itemBOQUpdateDto.BoqItemId, 10) },
        { name: 'ItemDescription', type:sql.VarChar, value: itemBOQUpdateDto.ItemDescription?.trim()  },
        { name: 'ItemCode', type:sql.VarChar, value: itemBOQUpdateDto.ItemCode?.trim() },
        { name: 'Quantity', type:sql.Int, value: itemBOQUpdateDto.Quantity },
        { name: 'EstimatedRate', type:sql.Int, value: itemBOQUpdateDto.EstimatedRate },
        { name: 'Model', type:sql.VarChar, value: itemBOQUpdateDto.Model },
        { name: 'Unit', type:sql.Int, value: itemBOQUpdateDto.Unit },
        { name: 'Specification', type:sql.VarChar, value: itemBOQUpdateDto.Specification?.trim() },
        { name: 'AdditionalValue1', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue1 },
        { name: 'AdditionalValue2', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue2 },
        { name: 'AdditionalValue3', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue3 },
        { name: 'AdditionalValue4', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue4 },
        { name: 'AdditionalValue5', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue5 },
        { name: 'AdditionalValue6', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue6 },
        { name: 'AdditionalValue7', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue7 },
        { name: 'AdditionalValue8', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue8 },
        { name: 'AdditionalValue9', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue9 },
        { name: 'AdditionalValue10', type: sql.VarChar, value: itemBOQUpdateDto.AdditionalValue10 },
        { name: 'ModifyBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.resultBOQService.boqItemUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("result_boq_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("result_boq_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
  async updateResultBOQ(resultBOQUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'BoqItemsDetailsId', type:sql.Int, value: resultBOQUpdateDto.BoqItemsDetailsId },
        { name: 'BidderName', type:sql.VarChar, value: resultBOQUpdateDto.BidderName?.trim() },
        { name: 'UnitPrice', type:sql.Int, value: resultBOQUpdateDto.UnitPrice },
        { name: 'Brand', type:sql.Int, value: resultBOQUpdateDto.Brand },
        { name: 'TotalAmount', type:sql.Int, value: resultBOQUpdateDto.TotalAmount },
        { name: 'GST', type:sql.VarChar, value: resultBOQUpdateDto.GST?.trim() },
        { name: 'ExciseDuty', type:sql.Int, value: resultBOQUpdateDto.ExciseDuty },
        { name: 'FreightChargres', type:sql.Int, value: resultBOQUpdateDto.FreightChargres },
        { name: 'ModifyBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.resultBOQService.boqResultUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].user_id === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("result_boq_bidder_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("result_boq_bidder_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
  async holdResultBOQ(resultBOQHoldDto: any,userId:any): Promise<any> {
    try {
      // const isAdmin = UserUpdateDto.is_admin ? 1 : 0;
      const inputParams = [
        { name: 'BoqItemId', type:sql.Int, value: resultBOQHoldDto.boqItemId },
        { name: 'comments', type: sql.VarChar, value: resultBOQHoldDto.Comments },
        { name: 'OnHoldby', type:sql.Int, value: userId  },
      ];
      const outputParams = []
      const result = await this.resultBOQService.boqResultHold(inputParams,outputParams);

      if (result.Data[0].Status !== 0) {
          return ApiResponse(Success, "Data Hold successfully.", true, result.Data, result.Data.length);
      } else {
        this.loggerService.error("hold_result_boq_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("hold_result_boq_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async resultSearch(tenderSearchDto: any, userId: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'Resultid', type: sql.VarChar, value: tenderSearchDto.TenderResultId },
        { name: 'TenderNumber', type: sql.VarChar, value: tenderSearchDto.TenderNumber },
        { name: 'OrganizationId', type: sql.VarChar, value: (tenderSearchDto.OrganizationId=="0" || tenderSearchDto.OrganizationId=="null")? "":tenderSearchDto.OrganizationId },
        { name: 'ModifiedDateTo', type: sql.VarChar, value: tenderSearchDto.CreatedDateTo || null },
        { name: 'ModifiedDateFrom', type: sql.VarChar, value: tenderSearchDto.CreatedDateFrom || null },
        { name: 'AssignBy', type: sql.VarChar, value: tenderSearchDto.AssignBy=="0"? String(userId): tenderSearchDto.AssignBy},
        { name: 'OnHold', type: sql.Bit, value: tenderSearchDto.OnHold }
      ];
      const outputParams = []
      const result = await this.resultBOQService.resultSearch(inputParams, outputParams);

      if (result.Success) {
        return ApiResponse(Success, "Success", true, result.Data, result.Data.length);
      } else {
        this.loggerService.error("result_search_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("result_search_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async boqGetByIdResult(BoqItemId: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'BoqItemId', type: sql.Int, value: BoqItemId },
      ];
      const outputParams = []
      const result = await this.resultBOQService.boqGetByIdResult(inputParams,outputParams);
      return result
    } catch (error) {
      this.loggerService.error("boqGetByIdResult_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
}
