import { Injectable } from '@nestjs/common';
import { UserService } from '../service/user.service'; // Assume you have a SqlService for SQL operations
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
@Injectable()
export class UserRepository {

  constructor(
    private readonly userService: UserService,
    private readonly loggerService: LoggerService,
    ) {}

  async getAllUsers(): Promise<any> {
    try {
      const result = await this.userService.getAllUser(); // Adjust method call
      return result;
    } catch (error) {
      this.loggerService.error("user_getall_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async insertUser(UserInsertDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UserName', type:sql.VarChar, value: UserInsertDto.UserName },
        { name: 'Password', type: sql.VarChar, value: UserInsertDto.Password  },
        { name: 'Mobile', type:sql.VarChar, value: UserInsertDto.Mobile },
        { name: 'Address', type:sql.VarChar, value: UserInsertDto.Address },
        { name: 'UserTypeID', type:sql.Bit, value: UserInsertDto.UserTypeID },
        { name: 'RoleId', type:sql.Int, value: UserInsertDto.RoleId },
        { name: 'CreatedBy', type:sql.Int, value:userId },
      ];
      
      const outputParams = []
      const result = await this.userService.userInsert(inputParams,outputParams)

          return ApiResponse(Success, 'Data added successfully.', true, result.Data, result.Data.length);
    } catch (error) {
      this.loggerService.error("user_insert_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async getUserById(userId: number): Promise<any> {
    try {
      const inputParams = [{ name: 'user_id', type: sql.Int, value: userId }];
      const outputParams = []
      const result = await this.userService.userGetById(inputParams,outputParams);
      return result;
    } catch (error) {
      this.loggerService.error("user_get_by_id_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async updateUser(UserUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UserID', type:sql.Int, value: UserUpdateDto.UserID },
        { name: 'UserName', type:sql.VarChar, value: UserUpdateDto.UserName  },
        { name: 'Password', type:sql.VarChar, value: UserUpdateDto.Password },
        { name: 'Mobile', type: sql.VarChar, value: UserUpdateDto.Mobile },
        { name: 'Address', type: sql.VarChar, value: UserUpdateDto.Address  },
        { name: 'UserTypeID', type:sql.Bit, value: UserUpdateDto.UserTypeID },
        { name: 'RoleId', type:sql.Int, value: UserUpdateDto.RoleId },
        { name: 'ModifiedBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.userService.userUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].user_id === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("user_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("user_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async deleteUser(user_id: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'UserID', type: sql.Int, value: user_id },
        { name: 'ModifiedBy', type: sql.Int, value: modifyBy },
      ];
      const outputParams = []
      const result = await this.userService.userDelete(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].Status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data deleted successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("user_delete_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("user_delete_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
  async getAllRoles(): Promise<any> {
    try {
      const result = await this.userService.getAllRole(); // Adjust method call
      return result;
    } catch (error) {
      this.loggerService.error("role_getall_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }
}
