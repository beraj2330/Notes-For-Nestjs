import { Injectable } from '@nestjs/common';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
import { DateUtilsService } from '../helper/dateHelper';
import { UnitAbbreviationService } from '../service/unitAbbreviation.service';
@Injectable()
export class UnitAbbreviationRepository {

  constructor(
    private readonly UnitAbbreviationMasterService: UnitAbbreviationService,
    private readonly loggerService: LoggerService,
    private readonly dateUtilsService: DateUtilsService,
    ) {}

  async getAllUnitAbbreviation(): Promise<any> {
    try {
      const result = await this.UnitAbbreviationMasterService.getAllUnitAbbreviation(); // Adjust method call
      const dateconvert = () => {
        return result.Data.map((res: any) => ({
          ...res,
          CreatedDate:  this.dateUtilsService.dateToDDMMYYYY(res?.CreatedDate),
        }));
      };
      const data = { unitDetail: dateconvert() } as any;
      return ApiResponse(Success, 'Success', true, data, result?.Data.length,false);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_getall_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async insertUnitAbbreviation(UnitAbbreviation: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitMasterid', type:sql.Int, value: UnitAbbreviation.UnitMasterid },
        { name: 'Abbreviation', type:sql.VarChar, value: UnitAbbreviation.Abbreviation },
        { name: 'CreatedBy', type:sql.Int, value:userId },
      ];
      const outputParams = []
      const result = await this.UnitAbbreviationMasterService.unitAbbreviationInsert(inputParams,outputParams)
          return ApiResponse(Success, 'Data added successfully.', true, result.Data, result.Data.length);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_insert_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async updateUnitAbbreviation(UnitAbbreviationUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitMasterAbbreviationid', type:sql.Int, value: UnitAbbreviationUpdateDto.UnitMasterAbbreviationid },
        { name: 'UnitMasterid', type:sql.Int, value: UnitAbbreviationUpdateDto.UnitMasterid },
        { name: 'Abbreviation', type:sql.VarChar, value: UnitAbbreviationUpdateDto.Abbreviation  },
        { name: 'ModifyBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.UnitAbbreviationMasterService.unitAbbreviationUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].user_id === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("unit_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("unit_abbreviation_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async deleteUnitAbbreviation(UnitMasterAbbreviationid: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitMasterAbbreviationid', type: sql.Int, value: UnitMasterAbbreviationid },
        { name: 'ModifiedBy', type: sql.Int, value: modifyBy },
      ];
      const outputParams = []
      const result = await this.UnitAbbreviationMasterService.unitAbbreviationDelete(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].Status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data deleted successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("unit_abbreviation_delete_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("unit_delete_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
}
