import { Injectable } from '@nestjs/common';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
import { UnitMasterService } from '../service/unitMaster.service';
import { DateUtilsService } from '../helper/dateHelper';
@Injectable()
export class UnitMasterRepository {

  constructor(
    private readonly UnitMasterService: UnitMasterService,
    private readonly loggerService: LoggerService,
    private readonly dateUtilsService: DateUtilsService,
    ) {}

  async getAllUnit(): Promise<any> {
    try {
      const result = await this.UnitMasterService.getAllUnit(); // Adjust method call
      const dateconvert = () => {
        return result.Data.map((res: any) => ({
          ...res,
          CreatedDate:  this.dateUtilsService.dateToDDMMYYYY(res?.CreatedDate),
        }));
      };
      const data = { unitDetail: dateconvert() } as any;
      return ApiResponse(Success, 'Success', true, data, result?.Data.length,false);
    } catch (error) {
      this.loggerService.error("unit_getall_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async insertUnit(UnitInsertDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitName', type:sql.VarChar, value: UnitInsertDto.UnitName },
        { name: 'CreatedBy', type:sql.Int, value:userId },
      ];
      
      const outputParams = []
      const result = await this.UnitMasterService.unitInsert(inputParams,outputParams)
          return ApiResponse(Success, 'Data added successfully.', true, result.Data, result.Data.length);
    } catch (error) {
      this.loggerService.error("unit_insert_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async updateUnit(UnitUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitMasterid', type:sql.Int, value: UnitUpdateDto.UnitMasterid },
        { name: 'UnitName', type:sql.VarChar, value: UnitUpdateDto.UnitName  },
        { name: 'ModifyBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.UnitMasterService.unitUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].user_id === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("unit_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("unit_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async deleteUnit(UnitMasterid: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'UnitMasterid', type: sql.Int, value: UnitMasterid },
        { name: 'ModifiedBy', type: sql.Int, value: modifyBy },
      ];
      const outputParams = []
      const result = await this.UnitMasterService.unitDelete(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].Status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data deleted successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("unit_delete_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("unit_delete_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
}
