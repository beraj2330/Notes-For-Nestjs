import * as sql from 'mssql';
import { Injectable } from '@nestjs/common';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { TokenService } from '../utils/token'; // Assuming you have a TokenService
import { AuthService } from '../service/authenticate.Service'; // Assuming you have an AuthService
@Injectable()
export class AuthRepository {
  constructor(
    private readonly authService: AuthService,
    private readonly tokenService: TokenService, // Inject your token service
  ) {}

  async loginRepository(body: any): Promise<any> {
    try {
      const inputParams = [
        { name: 'UserName', type: sql.VarChar, value: body.UserName },
        { name: 'Password', type: sql.VarChar, value: body.Password },
      ];
      
      const outputParams = [];
      const result = await this.authService.login(inputParams, outputParams);
      
      if (result.Success && result.TotalRecord > 0) {
        const employeeDetail = result.Data[0];
        const jsonToken = this.tokenService.createToken(employeeDetail); // Generate token
        employeeDetail["token"] = jsonToken;
        result.Data = employeeDetail;
        result.Message = 'you have successfully logged in'; // Assuming you have a success message
        return ApiResponse(200, result.Message, true, result.Data, 1, true);
      } else {
        return ApiResponse(500, "Invalid User Name and Password.", false, [], 0, false);
      }
    } catch (error) {
      console.error("login_repository catch", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }
}
