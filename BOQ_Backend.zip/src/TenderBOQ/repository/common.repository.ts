import { Injectable, Logger } from '@nestjs/common';
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import path if necessary
import { CacheService } from '../helper/cache.service'; // Adjust import path if necessary
import { CommonService } from '../service/common.service';
import { FilterFunctionsService  } from '../helper/filterFunctions'; // Adjust import path if necessary
import { LoggerService } from '../utils/logger.service';

@Injectable()
export class CommonRepository {
  private readonly logger = new Logger(CommonRepository.name);

  constructor(
    private readonly commonService: CommonService,
    private readonly cacheService: CacheService, // Inject CacheService
    private readonly filterFunctionsService: FilterFunctionsService, 
    private readonly loggerService: LoggerService,
  ) {}

  async getAllLocation(body: any) {
    try {
      const { id, parentids, noofrecords, pageNo, name } = body;
      const cachedData = this.cacheService.getCache('allLocation') as any[]; // Type assertion
      // Use cacheService
      if (cachedData && cachedData !== null && cachedData.length > 0 ) {
        const data =  this.filterFunctionsService.locationFilterFunction(id,cachedData, parentids, noofrecords, pageNo, name);
        return ApiResponse(200, 'Success', true, data, data.length, true);
      }
      const result = await this.commonService.getAllLocation();
      this.cacheService.setCache('allLocation', result.Data); // Use cacheService
      const data =  this.filterFunctionsService.locationFilterFunction(id,result.Data, parentids, noofrecords, pageNo, name);
      return ApiResponse(200, 'Success', true, data, data.length, true);
    } catch (error) {
      this.loggerService.error("getAllLocation",error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async OrganizationGetAll(body: any) {
    try {
      const { id, parentids, noofrecords, pageNo, name } = body;
      const cachedData = this.cacheService.getCache('OrganizationGetAll') as any[]; // Type assertion
      // Use cacheService
      if (cachedData && cachedData !== null && cachedData.length > 0 ) {
        const data =  this.filterFunctionsService.OrganizationFilterFunction(id,cachedData, parentids, noofrecords, pageNo, name);
        return ApiResponse(200, 'Success', true, data, data.length, true);
      }
      const result = await this.commonService.OrganizationGetAll();
      this.cacheService.setCache('OrganizationGetAll', result.Data); // Use cacheService
      const data =  this.filterFunctionsService.OrganizationFilterFunction(id,result.Data, parentids, noofrecords, pageNo, name);
      return ApiResponse(200, 'Success', true, data, data.length, true);
    } catch (error) {
      this.loggerService.error("OrganizationGetAll",error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }
  async UnitMasterGetAll(body: any) {
    try {
      const { id, parentids, noofrecords, pageNo, name } = body;
      // const cachedData = this.cacheService.getCache('OrganizationGetAll') as any[]; // Type assertion
      // // Use cacheService
      // if (cachedData && cachedData !== null && cachedData.length > 0 ) {
      //   const data =  this.filterFunctionsService.OrganizationFilterFunction(id,cachedData, parentids, noofrecords, pageNo, name);
      //   return ApiResponse(200, 'Success', true, data, data.length, true);
      // }
      const result = await this.commonService.UnitMasterGetAll();
      // this.cacheService.setCache('OrganizationGetAll', result.Data); // Use cacheService
      const data =  this.filterFunctionsService.UnitMasterFilterFunction(id,result.Data, parentids, noofrecords, pageNo, name);
      return ApiResponse(200, 'Success', true, data, data.length, true);
    } catch (error) {
      this.loggerService.error("UnitMasterGetAll",error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }
}
