import { Injectable } from '@nestjs/common';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Adjust import paths
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import paths
import * as sql from 'mssql';
import { LoggerService } from '../utils/logger.service';
import { DateUtilsService } from '../helper/dateHelper';
import { BrandAbbreviationService } from '../service/brandAbbreviation.service';
@Injectable()
export class BrandAbbreviationRepository {

  constructor(
    private readonly BrandAbbreviationService: BrandAbbreviationService,
    private readonly loggerService: LoggerService,
    private readonly dateUtilsService: DateUtilsService,
    ) {}

  async getAllBrandAbbreviation(): Promise<any> {
    try {
      const result = await this.BrandAbbreviationService.getAllBrandAbbreviation(); // Adjust method call
      const dateconvert = () => {
        return result.Data.map((res: any) => ({
          ...res,
          CreatedDate:  this.dateUtilsService.dateToDDMMYYYY(res?.CreatedDate),
        }));
      };
      const data = { brandDetail: dateconvert() } as any;
      return ApiResponse(Success, 'Success', true, data, result?.Data.length,false);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_getall_repository", error);
      return ApiResponse(500, error.toString(), false, [], 0, false);
    }
  }

  async insertBrandAbbreviation(BrandAbbreviationInsert: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'BrandMasterid', type:sql.Int, value: BrandAbbreviationInsert.BrandMasterid },
        { name: 'Abbreviation', type:sql.VarChar, value: BrandAbbreviationInsert.Abbreviation },
        { name: 'CreatedBy', type:sql.Int, value:userId },
      ];
      const outputParams = []
      const result = await this.BrandAbbreviationService.brandAbbreviationInsert(inputParams,outputParams)
          return ApiResponse(Success, 'Data added successfully.', true, result.Data, result.Data.length);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_insert_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async updateBrandAbbreviation(BrandAbbreviationUpdateDto: any,userId:any): Promise<any> {
    try {
      const inputParams = [
        { name: 'BrandMasterAbbreviationid', type:sql.Int, value: BrandAbbreviationUpdateDto.BrandMasterAbbreviationid },
        { name: 'BrandMasterid', type:sql.Int, value: BrandAbbreviationUpdateDto.BrandMasterid },
        { name: 'Abbreviation', type:sql.VarChar, value: BrandAbbreviationUpdateDto.Abbreviation  },
        { name: 'ModifyBy', type:sql.Int, value: userId },
      ];
      const outputParams = []
      const result = await this.BrandAbbreviationService.brandAbbreviationUpdate(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].user_id === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data updated successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("brand_abbreviation_update_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("brand_update_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }

  async deleteBrandAbbreviation(BrandMasterAbbreviationid: number, modifyBy: number): Promise<any> {
    try {
      const inputParams = [
        { name: 'BrandMasterAbbreviationid', type: sql.Int, value: BrandMasterAbbreviationid },
        { name: 'ModifiedBy', type: sql.Int, value: modifyBy },
      ];
      const outputParams = []
      const result = await this.BrandAbbreviationService.brandAbbreviationDelete(inputParams,outputParams);

      if (result.Success) {
        if (result.Data[0].Status === 0) {
          return ApiResponse(ServerError, result.Message, false, result.Data, result.Data.length);
        } else {
          return ApiResponse(Success, 'Data deleted successfully.', true, result.Data, result.Data.length);
        }
      } else {
        this.loggerService.error("brand_abbreviation_delete_repository", result);
        return ApiResponse(BadRequest, result.Message, false);
      }
    } catch (error) {
      this.loggerService.error("brand_abbreviation_delete_repository catch", error);
      return ApiResponse(ServerError, error.toString(), false, [], 0, false);
    }
  }
}
