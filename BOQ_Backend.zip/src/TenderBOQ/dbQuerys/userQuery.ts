export const UserQueries = {
    user_getall: 'UserMaster_getAll',
    user_insert: 'UserMaster_insert',
    user_getbyid: 'User_Master_GetByID',
    user_update: 'UserMaster_update',
    user_delete: 'UserMaster_delete',
    role_getall: 'Role_getAll',
  };
  