export const tenderBOQQuery = {
  getone_tenderboq: 'Tender_BOQ_Get',
  update_tenderboq: 'Tender_BOQ_Update',
  hold_tenderboq: 'Tender_BOQ_OnHold',
  tender_search: 'Search_TenderBOQ',
  tender_getbyid: 'Get_Tender_By_BOQid',
  };
  