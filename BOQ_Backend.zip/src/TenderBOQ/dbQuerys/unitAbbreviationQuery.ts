export const unitAbbreviationQueries = {
  unitAbbreviation_getall: 'UnitMasterAbbreviation_getAll',
  unitAbbreviation_insert: 'UnitMasterAbbreviation_insert',
  unitAbbreviation_getbyid: 'Unit_MasterAbbreviation_GetByID',
  unitAbbreviation_update: 'UnitMasterAbbreviation_update',
  unitAbbreviation_delete: 'UnitMasterAbbreviation_delete',
  };
  