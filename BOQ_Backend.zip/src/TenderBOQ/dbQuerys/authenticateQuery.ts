// src/dbQuerys/authenticateQuery.ts

export const dbSqlQuery = {
    login: "Authenticate_User",
  };
  