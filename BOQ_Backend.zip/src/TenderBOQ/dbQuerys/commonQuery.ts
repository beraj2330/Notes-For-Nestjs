export const CommonQueries = {
    organization_getall: "Organization_getAll",
    location_getall: "Node_SelectAllSiteLocationMaster",
    unitMaster_getall: "UnitMaster_getAll",
  };
  