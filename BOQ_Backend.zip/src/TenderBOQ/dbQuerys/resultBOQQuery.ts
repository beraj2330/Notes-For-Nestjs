export const resultBOQQuery = {
  getone_resultboq: 'Result_BOQ_Get',
  getone_bidderdetails: 'Result_BOQ_Bidder_Get',
  update_itemboq: 'Result_BOQ_Item_Update',
  update_resultboq: 'Result_BOQ_Item_Bidder_Update',
  hold_resultboq: 'Result_BOQ_OnHold',
  result_search: 'Search_ResultBOQ',
  result_getbyid: 'Get_Result_By_BOQid',
  };
  