export const brandMasterQueries = {
  brand_getall: 'BrandMaster_getAll',
  brand_insert: 'BrandMaster_Insert',
  brand_getbyid: 'Brand_Master_GetByID',
  brand_update: 'BrandMaster_update',
  brand_delete: 'BrandMaster_delete',
  };
  