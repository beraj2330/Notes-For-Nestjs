export const unitMasterQueries = {
  unit_getall: 'UnitMaster_getAll',
  unit_insert: 'UnitMaster_insert',
  unit_getbyid: 'Unit_Master_GetByID',
  unit_update: 'UnitMaster_update',
  unit_delete: 'UnitMaster_delete',
  };
  