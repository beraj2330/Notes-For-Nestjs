export const brandAbbreviationQueryQueries = {
  brandAbbreviation_getall: 'BrandMasterAbbreviation_getAll',
  brandAbbreviation_insert: 'BrandMasterAbbreviation_insert',
  brandAbbreviation_update: 'BrandMasterAbbreviation_update',
  brandAbbreviation_delete: 'BrandMasterAbbreviation_delete',
  };