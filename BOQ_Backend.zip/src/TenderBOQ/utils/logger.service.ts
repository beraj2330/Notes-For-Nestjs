import { Injectable, LoggerService as NestLoggerService } from '@nestjs/common';
import * as winston from 'winston';
import * as moment from 'moment-timezone';
import * as path from 'path';
import * as fs from 'fs';
import 'winston-daily-rotate-file';  // This ensures winston-daily-rotate-file is imported

@Injectable()
export class LoggerService implements NestLoggerService {
  private infoLogger: winston.Logger;
  private errorLogger: winston.Logger;
  private PROJECT_ROOT = path.join(__dirname, '..');

  constructor() {
    const logsDir = path.join(__dirname, 'logs');
    if (!fs.existsSync(logsDir)) {
      fs.mkdirSync(logsDir);
    }

    this.infoLogger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp({
          format: () => moment().format('YYYY-MM-DD HH:mm:ss'),
        }),
        winston.format.printf(({ timestamp, level, message }) => {
          return `${timestamp} [${level.toUpperCase()}] : ${message}`;
        }),
      ),
      defaultMeta: { service: 'user-service' },
      transports: [
        // new winston.transports.Console(),
        new (winston.transports as any).DailyRotateFile({
          filename: 'logs/info-%DATE%.log',
          datePattern: 'YYYY-MM-DD',
          level: 'info',
          zippedArchive: true,
          maxSize: '20m',
          maxFiles: '14d',
        }),
      ],
    });

    this.errorLogger = winston.createLogger({
      level: 'error',
      format: winston.format.combine(
        winston.format.timestamp({
          format: () => moment().format('YYYY-MM-DD HH:mm:ss'),
        }),
        winston.format.printf(({ timestamp, level, message }) => {
          return `${timestamp} [${level.toUpperCase()}] : ${message}`;
        }),
      ),
      transports: [
        // new winston.transports.Console(),
        new (winston.transports as any).DailyRotateFile({
          filename: 'logs/error-%DATE%.log',
          datePattern: 'YYYY-MM-DD',
          level: 'error',
          zippedArchive: true,
          maxSize: '20m',
          maxFiles: '14d',
        }),
      ],
    });
  }

  log(message: string) {
    this.infoLogger.info(message);
  }

  error(message: string, trace: string) {
    this.errorLogger.error(`${message} - ${trace}`);
  }

  warn(message: string) {
    this.infoLogger.warn(message);
  }

  debug(message: string) {
    this.infoLogger.debug(message);
  }

  verbose(message: string) {
    this.infoLogger.verbose(message);
  }

  info(functionName: string, message: any) {
    this.infoLogger.info(`Path: ${this.formatLogArguments(message)} | Function: ${functionName} \nMessage: ${JSON.stringify(message)}`);
  }

  logError(functionName: string, message: any) {
    this.errorLogger.error(`Path: ${this.formatLogArguments(message)} | Function: ${functionName} \nMessage: ${JSON.stringify(message)}`);
  }

  private formatLogArguments(args: any): string {
    const stackInfo = this.getStackInfo(1);
    let calleeStr = '';
    if (stackInfo) {
      calleeStr = `:${stackInfo.relativePath} | Line:${stackInfo.line}:${stackInfo.pos} | File: ${stackInfo.file}`;
    }
    return calleeStr;
  }

  private getStackInfo(stackIndex: number): any {
    const stacklist = new Error().stack.split('\n').slice(3);
    const stackReg = /at\s+(.*)\s+\((.*):(\d*):(\d*)\)/gi;
    const stackReg2 = /at\s+()(.*):(\d*):(\d*)/gi;
    const s = stacklist[stackIndex] || stacklist[0];
    const sp = stackReg.exec(s) || stackReg2.exec(s);

    if (sp && sp.length === 5) {
      return {
        method: sp[1],
        relativePath: path.relative(this.PROJECT_ROOT, sp[2]),
        line: sp[3],
        pos: sp[4],
        file: path.basename(sp[2]),
        stack: stacklist.join('\n'),
      };
    }
  }
}
