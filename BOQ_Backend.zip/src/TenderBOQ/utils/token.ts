import { Injectable } from '@nestjs/common';
import { sign, verify } from 'jsonwebtoken';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class TokenService {
    constructor(private readonly configService: ConfigService) {}

  createToken(results: any): string {
    const currentDate = new Date();
    const expirationDate = new Date(currentDate);
    expirationDate.setDate(currentDate.getDate() + 1);
    expirationDate.setHours(0, 0, 0, 0);
    const expiresIn = Math.floor((expirationDate.getTime() - currentDate.getTime()) / 1000);

    return sign({ result: results }, this.configService.get<string>('ACCESS_TOKEN_SECRET'), {
      expiresIn,
    });
  }
}
