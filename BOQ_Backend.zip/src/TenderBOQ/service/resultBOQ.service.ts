import { Injectable } from '@nestjs/common';
import { resultBOQQuery } from '../dbQuerys/resultBOQQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class resultBOQService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getOneBOQResult(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.getone_resultboq, inputParams, outputParams);
  }
  async boqGetBidder(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.getone_bidderdetails, inputParams, outputParams);
  }
  async boqItemUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.update_itemboq, inputParams, outputParams);
  }
  async boqResultUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.update_resultboq, inputParams, outputParams);
  }
  async boqResultHold(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.hold_resultboq, inputParams, outputParams);
  }
  async resultSearch(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.result_search, inputParams, outputParams);
  }
  async boqGetByIdResult(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(resultBOQQuery.result_getbyid, inputParams, outputParams);
  }
}

