import { Injectable } from '@nestjs/common';
import { tenderBOQQuery } from '../dbQuerys/tenderBOQQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class tenderBOQService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getOneBOQTender(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(tenderBOQQuery.getone_tenderboq, inputParams, outputParams);
  }
  async boqTenderUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(tenderBOQQuery.update_tenderboq, inputParams, outputParams);
  }
  async boqTenderHold(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(tenderBOQQuery.hold_tenderboq, inputParams, outputParams);
  }
  async tenderSearch(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(tenderBOQQuery.tender_search, inputParams, outputParams);
  }
  async boqGetByIdTender(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(tenderBOQQuery.tender_getbyid, inputParams, outputParams);
  }
}

