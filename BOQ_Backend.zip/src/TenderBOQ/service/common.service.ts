import { Injectable } from '@nestjs/common';
import { CommonQueries } from '../dbQuerys/commonQuery'; // Adjust import path
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class CommonService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllLocation() {
    return this.dbSqlContext.queryHandler(CommonQueries.location_getall);
  }
  async OrganizationGetAll() {
    return this.dbSqlContext.queryHandler(CommonQueries.organization_getall);
  }
  async UnitMasterGetAll() {
    return this.dbSqlContext.queryHandler(CommonQueries.unitMaster_getall);
  }
}
