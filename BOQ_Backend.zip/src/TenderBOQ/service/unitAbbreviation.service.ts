import { Injectable } from '@nestjs/common';
import { unitAbbreviationQueries } from '../dbQuerys/unitAbbreviationQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class UnitAbbreviationService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllUnitAbbreviation(): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitAbbreviationQueries.unitAbbreviation_getall);
  }

  async unitAbbreviationInsert(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitAbbreviationQueries.unitAbbreviation_insert, inputParams, outputParams);
  }

  async unitAbbreviationUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitAbbreviationQueries.unitAbbreviation_update, inputParams, outputParams);
  }

  async unitAbbreviationDelete(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitAbbreviationQueries.unitAbbreviation_delete, inputParams, outputParams);
  }
}
