import { Injectable } from '@nestjs/common';
import { brandAbbreviationQueryQueries } from '../dbQuerys/brandAbbreviationQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class BrandAbbreviationService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllBrandAbbreviation(): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandAbbreviationQueryQueries.brandAbbreviation_getall);
  }

  async brandAbbreviationInsert(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandAbbreviationQueryQueries.brandAbbreviation_insert, inputParams, outputParams);
  }

  async brandAbbreviationUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandAbbreviationQueryQueries.brandAbbreviation_update, inputParams, outputParams);
  }

  async brandAbbreviationDelete(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandAbbreviationQueryQueries.brandAbbreviation_delete, inputParams, outputParams);
  }
}
