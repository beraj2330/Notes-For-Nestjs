import { Injectable } from '@nestjs/common';
import { unitMasterQueries } from '../dbQuerys/unitMasterQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class UnitMasterService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllUnit(): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitMasterQueries.unit_getall);
  }

  async unitInsert(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitMasterQueries.unit_insert, inputParams, outputParams);
  }

  async unitUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitMasterQueries.unit_update, inputParams, outputParams);
  }

  async unitDelete(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(unitMasterQueries.unit_delete, inputParams, outputParams);
  }
}
