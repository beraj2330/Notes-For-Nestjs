import { Injectable } from '@nestjs/common';
import { dbSqlQuery } from '../dbQuerys/authenticateQuery';
import { QueryHandlerPgService } from '../middlewares/queryHandlerPg';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class AuthService {
  constructor(
    private readonly queryHandlerService: QueryHandlerService,
    private readonly queryHandlerPgService: QueryHandlerPgService,
    ) {}
  async login(inputParams: any[], outParams: any[]): Promise<any> {
    try {
      return await this.queryHandlerService.queryHandler(dbSqlQuery.login, inputParams, outParams);
    } catch (error) {
      console.error('AuthService login error:', error);
      throw new Error('Failed to execute login query');
    }
  }
}
