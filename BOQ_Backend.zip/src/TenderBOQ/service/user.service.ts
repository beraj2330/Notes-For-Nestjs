import { Injectable } from '@nestjs/common';
import { UserQueries } from '../dbQuerys/userQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class UserService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllUser(): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.user_getall);
  }

  async userInsert(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.user_insert, inputParams, outputParams);
  }

  async userGetById(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.user_getbyid, inputParams, outputParams);
  }

  async userUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.user_update, inputParams, outputParams);
  }

  async userDelete(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.user_delete, inputParams, outputParams);
  }

  async getAllRole(): Promise<any> {
    return await this.dbSqlContext.queryHandler(UserQueries.role_getall);
  }
}
