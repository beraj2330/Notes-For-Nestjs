import { Injectable } from '@nestjs/common';
import { brandMasterQueries } from '../dbQuerys/brandMasterQuery';
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Injectable()
export class BrandMasterService {
  constructor(private readonly dbSqlContext: QueryHandlerService) {}

  async getAllBrand(): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandMasterQueries.brand_getall);
  }

  async brandInsert(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandMasterQueries.brand_insert, inputParams, outputParams);
  }

  async brandUpdate(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandMasterQueries.brand_update, inputParams, outputParams);
  }

  async brandDelete(inputParams: any[], outputParams: any[]): Promise<any> {
    return await this.dbSqlContext.queryHandler(brandMasterQueries.brand_delete, inputParams, outputParams);
  }
}
