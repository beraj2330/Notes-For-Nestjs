// src/dbContext/dbSqlContext.module.ts

import { Module } from '@nestjs/common';
import { DbPgService } from './dbPgContext'; // Path adjust karein
import { ConfigModule } from '@nestjs/config'; // Agar zarurat ho to

@Module({
  imports: [ConfigModule], // Import ConfigModule if needed
  providers: [DbPgService],
  exports: [DbPgService], // Export karein agar kisi aur module me use karna hai
})
export class DbPgModule {}
