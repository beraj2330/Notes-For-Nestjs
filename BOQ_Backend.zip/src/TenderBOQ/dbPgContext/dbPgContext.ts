import { Injectable } from '@nestjs/common';
import { Pool, PoolClient } from 'pg';
import { ConfigService } from '@nestjs/config';
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust the import path accordingly
import { ServerError, Success } from '../helper/apiStatusCode'; // Adjust the import path accordingly

@Injectable()
export class DbPgService {
  private pgPool: Pool;

  constructor(private readonly configService: ConfigService) {
    this.pgPool = new Pool({
      host: this.configService.get<string>('DB_PG_HOST'),
      user: this.configService.get<string>('DB_PG_USERNAME'),
      password: this.configService.get<string>('DB_PG_PASSWORD'),
      database: this.configService.get<string>('DB_PG_DATABASE'),
      port: parseInt(this.configService.get<string>('DB_PG_PORT'), 10),
      max: parseInt(this.configService.get<string>('DB_MAX_POOL_SIZE'), 10) || 1000,
    });
  }

  async pgQueryToList(query: any, params: any[] = []): Promise<any> {
    let client: PoolClient;
    try {
      client = await this.pgPool.connect();
      const result = await client.query(query, params);
      return ApiResponse(Success, 'success', true, result.rows, result.rowCount, true);
    } catch (error) {
      console.error('Error executing query:', error);
      throw ApiResponse(ServerError, error.message, false, [], 0, false);
    } finally {
      if (client) {
        client.release();
      }
    }
  }
}
