import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { QueryHandlerModule } from './middlewares/queryHandlerSQL.module';
import { LoggerModule } from './utils/logger.module';
import { loginController } from './controller/authenticate.controller';
import { AuthService } from './service/authenticate.Service';
import { AuthRepository } from './repository/authenticate.Repository';
import { TokenService } from './utils/token';
import { CacheService } from './helper/cache.service';
import { MessageHelper } from './helper/messageHelper';
import { CommonController } from './controller/common.controller';
import { UserController } from './controller/user.controller';
import { CommonRepository } from './repository/common.repository';
import { UserRepository } from './repository/user.repository';
import { CommonService } from './service/common.service';
import { UserService } from './service/user.service';
import { FilterFunctionsService } from './helper/filterFunctions';
import { QueryHandlerPgService } from './middlewares/queryHandlerPg';
import { DbPgService } from './dbPgContext/dbPgContext';
import { UnitMasterService } from './service/unitMaster.service';
import { UnitMasterController } from './controller/unitMaster.controller';
import { UnitMasterRepository } from './repository/unitMaster.repository';
import { DateUtilsService } from './helper/dateHelper';
import { UnitAbbreviationController } from './controller/unitAbbreviation.controller';
import { UnitAbbreviationRepository } from './repository/unitAbbreviation.repository';
import { UnitAbbreviationService } from './service/unitAbbreviation.service';
import { BrandMasterController } from './controller/brandMaster.controller';
import { BrandMasterRepository } from './repository/brandMaster.repository';
import { BrandMasterService } from './service/brandMaster.service';
import { BrandAbbreviationController } from './controller/brandAbbreviation.controller';
import { BrandAbbreviationRepository } from './repository/brandAbbreviation.repository';
import { BrandAbbreviationService } from './service/brandAbbreviation.service';
import { TenderBOQController } from './controller/tenderBOQ.controller';
import { tenderBOQRepository } from './repository/tenderBOQ.repository';
import { tenderBOQService } from './service/tenderBOQ.service';
import { ResultBOQController } from './controller/resultBOQ.controller';
import { resultBOQRepository } from './repository/resultBOQ.repository';
import { resultBOQService } from './service/resultBOQ.service';
@Module({
  imports: [ConfigModule.forRoot(), QueryHandlerModule, LoggerModule],
  controllers: [
    loginController,
    CommonController,
    UserController,
    UnitMasterController,
    UnitAbbreviationController,
    BrandMasterController,
    BrandAbbreviationController,
    TenderBOQController,
    ResultBOQController,
  ],
  providers: [
    AuthService,
    AuthRepository,
    CommonService,
    CommonRepository,
    UserRepository,
    UserService,
    UnitMasterRepository,
    UnitMasterService,
    UnitAbbreviationRepository,
    UnitAbbreviationService,
    BrandMasterRepository,
    BrandMasterService,
    BrandAbbreviationRepository,
    BrandAbbreviationService,
    tenderBOQRepository,
    tenderBOQService,
    resultBOQRepository,
    resultBOQService,
    FilterFunctionsService,
    QueryHandlerPgService,
    DateUtilsService,
    DbPgService,
    TokenService,
    CacheService,
    MessageHelper
  ],
  exports: [],
})
export class TenderBOQModule { }
