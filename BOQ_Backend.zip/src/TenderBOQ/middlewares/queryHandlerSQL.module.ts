// src/middlewares/queryHandlerSQL.module.ts

import { Module } from '@nestjs/common';
import { DbSqlModule } from '../dbSqlContext/dbSqlContext.module'; // Path adjust karein
import { QueryHandlerService } from '../dbSqlContext/queryHandlerSQL';

@Module({
  imports: [DbSqlModule], // Import the module containing DbSqlService
  providers: [QueryHandlerService],
  exports: [QueryHandlerService], // Export QueryHandlerService if needed
})
export class QueryHandlerModule {}
