import { Injectable } from '@nestjs/common';
import { DbPgService } from '../dbPgContext/dbPgContext'; // Import the DbPgService
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust the import path accordingly
import { ServerError, Success } from '../helper/apiStatusCode'; // Adjust the import path accordingly
import { LoggerService } from '../utils/logger.service'; // Adjust the import path accordingly

@Injectable()
export class QueryHandlerPgService {
  constructor(
    private readonly dbPgService: DbPgService, // Inject DbPgService
    private readonly logger: LoggerService
  ) {}

  async queryHandler(query: any, params: any[] = []): Promise<any> {
    try {
      const result = await this.dbPgService.pgQueryToList(query, params);

      if (result.rows && result.rows.length > 0) {
        return ApiResponse(Success, 'Success', true, result.rows, result.rows.length, true);
      } else {
        return ApiResponse(Success, 'No records found', true, [], 0, true);
      }
    } catch (error) {
        const errorData:any = {
            ...{
              query: JSON.stringify(query),
              params: JSON.stringify(params),
              error: error,
            },
          }
          console.log("queryHandler", errorData)

      if (error?.stack) {
        const getMessage = error.stack.split('\n');
        const errMsg = getMessage[0]?.replace('Error: ', '');
        return ApiResponse(ServerError, errMsg, false, [], 0, false);
      } else {
        return ApiResponse(ServerError, error.message, false, [], 0, false);
      }
    }
  }
}
