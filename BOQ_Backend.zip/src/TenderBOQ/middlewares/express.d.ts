import { User } from './your-types'; // Replace with the path to your User type definition if you have one

declare global {
  namespace Express {
    interface Request {
      user?: User; // Add 'user' property here. Adjust type if needed.
    }
  }
}
