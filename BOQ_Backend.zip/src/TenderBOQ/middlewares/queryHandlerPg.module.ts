// src/middlewares/queryHandlerSQL.module.ts

import { Module } from '@nestjs/common';
import { DbPgModule } from '../dbPgContext/dbPgContext.module';
import { QueryHandlerPgService } from './queryHandlerPg';

@Module({
  imports: [DbPgModule], // Import the module containing DbSqlService
  providers: [QueryHandlerPgService],
  exports: [QueryHandlerPgService], // Export QueryHandlerService if needed
})
export class QueryHandlerModule {}
