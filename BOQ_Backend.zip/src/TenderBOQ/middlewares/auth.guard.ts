import { Injectable, CanActivate, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Request } from 'express';
import { verify } from 'jsonwebtoken';
import { MessageHelper } from '../helper/messageHelper'; // Adjust import path as needed
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(
    private readonly configService: ConfigService,
    private readonly messageHelper: MessageHelper
  ) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest<Request>();
    const authHeader = request.headers.authorization;
    if (!authHeader) {
      throw new UnauthorizedException(this.messageHelper.getMessage('msg_error_token_authorized'));
    }

    // const token = authHeader; // Extract token from 'Bearer <token>'
    const token = authHeader.split(' ')[1]; // Extract token from 'Bearer <token>'

    if (!token) {
      throw new UnauthorizedException(this.messageHelper.getMessage('msg_error_token_authorized'));
    }

    try {
      const decoded = verify(token, this.configService.get<string>('ACCESS_TOKEN_SECRET'));
      request.user = decoded; // Attach the decoded token to the request
     
      return true;
    } catch (err) {
      throw new UnauthorizedException(this.messageHelper.getMessage('msg_error_not_valid_authorized'));
    }
  }
}
