import {
  Controller,
  Post,
  Body,
  Res,
  HttpStatus,
} from '@nestjs/common';
import { Response } from 'express';
import { CommonRepository } from '../repository/common.repository'; // Adjust import path
import { ApiResponse } from '../helper/apiResponse.middleware'; // Adjust import path
import { ServerError } from '../helper/apiStatusCode'; // Adjust import path
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { FilterDto } from '../dto/common.dto';
import { LoggerService } from '../utils/logger.service';
import * as fs from 'fs';
import * as XLSX from 'xlsx';
import { getExelDataDto } from '../dto/resultBOQ.dto';

@ApiTags('Common-controller')
@ApiBearerAuth('jwt')
@Controller('/api/common/')
export class CommonController {

  constructor(
    private readonly commonRepository: CommonRepository,
    private readonly loggerService: LoggerService,
  ) { }

  @Post('get-location-by-text')
  @ApiOperation({ summary: 'SP: Node_SelectAllSiteLocationMaster' })
  async getAllKeywords(@Body() FilterDto: FilterDto, @Res() res: Response) {
    try {
      const data = await this.commonRepository.getAllLocation(FilterDto);
      this.loggerService.info("get_location_by_text", data);
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("get_location_by_text", error);
      return res
        .status(HttpStatus.INTERNAL_SERVER_ERROR)
        .json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('organization-getall')
  @ApiOperation({ summary: 'SP: Organization_getAll' })
  async Organization_getAll(@Body() FilterDto: FilterDto, @Res() res: Response) {
    try {
      const data = await this.commonRepository.OrganizationGetAll(FilterDto);
      this.loggerService.info("Organization_getAll", data);
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("Organization_getAll", error);
      return res
        .status(HttpStatus.INTERNAL_SERVER_ERROR)
        .json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
  @Post('unit-master-getall')
  @ApiOperation({ summary: 'SP: UnitMaster_getAll' })
  async UnitMaster_getAll(@Body() FilterDto: FilterDto, @Res() res: Response) {
    try {
      const data = await this.commonRepository.UnitMasterGetAll(FilterDto);
      this.loggerService.info("UnitMaster_getAll", data);
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("UnitMaster_getAll", error);
      return res
        .status(HttpStatus.INTERNAL_SERVER_ERROR)
        .json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('get-excel-data')
  getExcelData(@Body() getExelDataDto: getExelDataDto, @Res() res: Response) {
    const filePath = getExelDataDto.filepath; // Use the filepath from the request body
    // Read the Excel file from the network share
    fs.readFile(filePath, async (err, fileData) => {
      if (err) {
        return res.status(500).send('File not found or unable to read the file');
      }
      // Parse the Excel file using XLSX
      const workbook = XLSX.read(fileData, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      return res.status(200).json(jsonData);
    });
  }

  @Post('get-excel-filter-data')
  getExcelFilterData(@Body() getExelDataDto: getExelDataDto, @Res() res: Response) {
    const filePath = getExelDataDto.filepath; // Use the filepath from the request body

    // Read the Excel file from the network share
    fs.readFile(filePath, async (err, fileData) => {
      if (err) {
        return res.status(500).send('File not found or unable to read the file');
      }

      // Parse the Excel file using XLSX
      const workbook = XLSX.read(fileData, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);

      const filteredData = jsonData.filter((row: any) => {
        // Log the trimmed values for comparison
        const rowValue = row['__EMPTY'] ? row['__EMPTY'].trim().toLowerCase() : '';
        const itemDescriptionValue = getExelDataDto.itemDescription ? getExelDataDto.itemDescription.trim().toLowerCase() : '';
        console.log(`Comparing: "${rowValue}" with "${itemDescriptionValue}"`);
        // Ensure the __EMPTY field exists and matches the itemDescription
        return rowValue == itemDescriptionValue;
    });
    
    return res.status(200).json(filteredData);
    });
  }

  @Post('get-excel-download')
  getExcelDownload(@Body() getExelDataDto: getExelDataDto, @Res() res: Response) {
    const filePath = getExelDataDto.filepath;

    // Ensure the file exists before attempting to read it
    fs.access(filePath, fs.constants.F_OK, (err) => {
      if (err) {
        return res.status(404).send('File not found');
      }

      // Read the file and stream it to the client as a download
      const fileStream = fs.createReadStream(filePath);

      fileStream.on('error', (streamErr) => {
        return res.status(500).send('Error reading the file');
      });

      // Set headers to indicate the content is an Excel file and should be downloaded
      res.setHeader('Content-Disposition', 'attachment; filename="' + filePath.split('\\').pop() + '"');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

      // Pipe the file stream to the response, effectively downloading it
      
      fileStream.pipe(res);
    });
  }
}
