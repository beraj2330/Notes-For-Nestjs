import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { tenderBOQRepository } from '../repository/tenderBOQ.repository';
import { tenderBOQHoldDto, tenderBOQUpdateDto, tenderSearchDto } from '../dto/tenderBOQ.dto';

@ApiTags('Tender-BOQ-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class TenderBOQController {

  constructor(
    private readonly tenderBOQRepository: tenderBOQRepository,
    private readonly loggerService: LoggerService,
  ) { }

  @Get('boq-tender-details-getone')
  @ApiOperation({ summary: 'SP: Tender_BOQ_Get', description: '' })
  @UseGuards(AuthGuard)
  async tender_details_getone(@Res() res: Response, @Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const data = await this.tenderBOQRepository.getOneBOQTender(userId);
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("boq_tender_getone", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('boq-tender-update')
  @ApiOperation({ summary: 'SP: Tender_BOQ_Update', description: '' })
  @UseGuards(AuthGuard)
  async tender_update(@Body() tenderBOQUpdateDto: tenderBOQUpdateDto, @Res() res: Response, @Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.tenderBOQRepository.updateTenderBOQ(tenderBOQUpdateDto, userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_tender_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('boq-tender-hold')
  @ApiOperation({ summary: 'SP: Tender_BOQ_OnHold', description: '' })
  @UseGuards(AuthGuard)
  async tender_hold(@Body() tenderBOQHoldDto: tenderBOQHoldDto, @Res() res: Response, @Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.tenderBOQRepository.holdTenderBOQ(tenderBOQHoldDto, userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_tender_hold", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('boq-tender-search')
  @ApiOperation({ summary: 'SP: Search_TenderBOQ', description: '' })
  @UseGuards(AuthGuard)
  async tender_search(@Body() tenderSearchDto: tenderSearchDto, @Res() res: Response, @Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.tenderBOQRepository.TenderSearch(tenderSearchDto, userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_tender_search", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Get('boq-tender-details-getbyid/:Boqid')
  @ApiOperation({ summary: 'SP: Get_Tender_By_BOQid', description: '' })
  @UseGuards(AuthGuard)
  async boq_getbyid_tender(@Param('Boqid') Boqid: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID
      const result = await this.tenderBOQRepository.boqGetByIdTender(Boqid,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_getbyid_tender", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}