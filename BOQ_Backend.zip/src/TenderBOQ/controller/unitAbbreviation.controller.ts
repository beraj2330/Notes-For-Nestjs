import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { UnitAbbreviationRepository } from '../repository/unitAbbreviation.repository';
import { UnitAbbreviation, UnitAbbreviationUpdateDto } from '../dto/unitAbbreviation.dto';

@ApiTags('Unit-abbreviation-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class UnitAbbreviationController {

  constructor(
    private readonly UnitAbbreviationRepository: UnitAbbreviationRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('unit-abbreviation-getall')
  @ApiOperation({ summary: 'SP: UnitMasterAbbreviation_getAll', description: '' })
  @UseGuards(AuthGuard)
  async unit_abbreviation_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.UnitAbbreviationRepository.getAllUnitAbbreviation();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('unit-abbreviation-insert')
  @ApiOperation({ summary: 'SP: UnitMasterAbbreviation_insert', description: '' })
  @UseGuards(AuthGuard)
  async unit_abbreviation_insert(@Res() res: Response ,@Body() UnitAbbreviation:UnitAbbreviation,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID || 0;
      const result = await this.UnitAbbreviationRepository.insertUnitAbbreviation(UnitAbbreviation,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_insert", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('unit-abbreviation-update')
  @ApiOperation({ summary: 'SP: UnitMasterAbbreviation_update', description: '' })
  @UseGuards(AuthGuard)
  async unit_abbreviation_update(@Body() UnitAbbreviationUpdateDto:UnitAbbreviationUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.UnitAbbreviationRepository.updateUnitAbbreviation(UnitAbbreviationUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Delete('unit-abbreviation-delete/:UnitMasterAbbreviationid')
  @ApiOperation({ summary: 'SP: UnitMasterAbbreviation_delete', description: '' })
  @UseGuards(AuthGuard)
  async unit_abbreviation_delete(@Param('UnitMasterAbbreviationid') UnitMasterAbbreviationid: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID;
      const result = await this.UnitAbbreviationRepository.deleteUnitAbbreviation(UnitMasterAbbreviationid,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_abbreviation_delete", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}
