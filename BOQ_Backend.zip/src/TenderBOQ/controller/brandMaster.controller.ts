import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { BrandMasterRepository } from '../repository/brandMaster.repository';
import { BrandInsertDto, BrandUpdateDto } from '../dto/brand.dto';

@ApiTags('Brand-master-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class BrandMasterController {

  constructor(
    private readonly BrandMasterRepository: BrandMasterRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('brand-getall')
  @ApiOperation({ summary: 'SP: BrandMaster_getAll', description: '' })
  @UseGuards(AuthGuard)
  async user_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.BrandMasterRepository.getAllBrand();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("brand_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('brand-master-insert')
  @ApiOperation({ summary: 'SP: BrandMaster_Insert', description: '' })
  @UseGuards(AuthGuard)
  async user_insert(@Res() res: Response ,@Body() BrandInsertDto:BrandInsertDto,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID || 0;
      const result = await this.BrandMasterRepository.insertBrand(BrandInsertDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_insert", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('brand-update')
  @ApiOperation({ summary: 'SP: BrandMaster_update', description: '' })
  @UseGuards(AuthGuard)
  async user_update(@Body() BrandUpdateDto:BrandUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.BrandMasterRepository.updateBrand(BrandUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Delete('brand-delete/:BrandMasterid')
  @ApiOperation({ summary: 'SP: BrandMaster_delete', description: '' })
  @UseGuards(AuthGuard)
  async user_delete(@Param('BrandMasterid') BrandMasterid: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID;
      const result = await this.BrandMasterRepository.deleteBrand(BrandMasterid,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_delete", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}
