import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { resultBOQRepository } from '../repository/resultBOQ.repository';
import { ResultBOQUpdateArrayDto, itemBOQUpdateDto, resultBOQHoldDto, resultSearchDto } from '../dto/resultBOQ.dto';

@ApiTags('Result-BOQ-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class ResultBOQController {

  constructor(
    private readonly resultBOQRepository: resultBOQRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('boq-result-details-getone')
  @ApiOperation({ summary: 'SP: Result_BOQ_Get', description: '' })
  @UseGuards(AuthGuard)
  async result_getall(@Res() res: Response, @Req() req: Request) {
    try {
        const userId = req.user?.result?.UserID
      const data = await this.resultBOQRepository.getOneBOQResult(userId);
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("boq_result_getone", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Get('item-wise-bidder/:boqItemId')
  @ApiOperation({ summary: 'SP: Result_BOQ_Bidder_Get', description: '' })
  @UseGuards(AuthGuard)
  async boq_get_bidder(@Param('boqItemId') boqItemId: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID
      const result = await this.resultBOQRepository.boqGetBidder(boqItemId,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_get_bidder", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('boq-item-update')
  @ApiOperation({ summary: 'SP: Result_BOQ_Item_Update', description: '' })
  @UseGuards(AuthGuard)
  async item_update(@Body() itemBOQUpdateDto:itemBOQUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.resultBOQRepository.updateItemBOQ(itemBOQUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_result_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('boq-bidder-update')
  @ApiOperation({ summary: 'SP: Result_BOQ_Item_Bidder_Update', description: '' })
  @UseGuards(AuthGuard)
  async result_update(@Body() ResultBOQUpdateArrayDto:ResultBOQUpdateArrayDto,@Res() res: Response,@Req() req: Request) {
    try {
      let results = [];
      const userId = req.user?.result?.UserID
      for (const resultBOQUpdateDto of ResultBOQUpdateArrayDto.data) {
        const result = await this.resultBOQRepository.updateResultBOQ(resultBOQUpdateDto, userId);
        results.push(result);
      }
      return res.status(200).json(results);
    } catch (error) {
      this.loggerService.error("boq_result_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('boq-result-hold')
  @ApiOperation({ summary: 'SP: Result_BOQ_OnHold', description: '' })
  @UseGuards(AuthGuard)
  async result_hold(@Body() resultBOQHoldDto:resultBOQHoldDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.resultBOQRepository.holdResultBOQ(resultBOQHoldDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_result_hold", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('boq-result-search')
  @ApiOperation({ summary: 'SP: Search_ResultBOQ', description: '' })
  @UseGuards(AuthGuard)
  async result_search(@Body() tenderSearchDto: resultSearchDto, @Res() res: Response, @Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.resultBOQRepository.resultSearch(tenderSearchDto, userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_result_search", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Get('boq-result-details-getbyid/:BoqItemId')
  @ApiOperation({ summary: 'SP: Get_Result_By_BOQid', description: '' })
  @UseGuards(AuthGuard)
  async boq_getbyid_result(@Param('BoqItemId') BoqItemId: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID
      const result = await this.resultBOQRepository.boqGetByIdResult(BoqItemId,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("boq_getbyid_result", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}