import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { UserRepository } from '../repository/user.repository'; // Ensure you have a service for user-related operations
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import {UserInsertDto,UserUpdateDto} from '../dto/user.dto'

@ApiTags('User-master-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class UserController {

  constructor(
    private readonly userRepository: UserRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('user-getall')
  @ApiOperation({ summary: 'SP: UserMaster_getAll', description: '' })
  @UseGuards(AuthGuard)
  async user_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.userRepository.getAllUsers();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("user_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('user-master-insert')
  @ApiOperation({ summary: 'SP: UserMaster_insert', description: '' })
  @UseGuards(AuthGuard)
  async user_insert(@Res() res: Response ,@Body() UserInsertDto:UserInsertDto,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID || 0;
      const result = await this.userRepository.insertUser(UserInsertDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("user_insert", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('user-update')
  @ApiOperation({ summary: 'SP: UserMaster_update', description: '' })
  @UseGuards(AuthGuard)
  async user_update(@Body() UserUpdateDto:UserUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.userRepository.updateUser(UserUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("user_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Delete('user-delete/:user_id')
  @ApiOperation({ summary: 'SP: UserMaster_delete', description: '' })
  @UseGuards(AuthGuard)
  async user_delete(@Param('user_id') user_id: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID;
      const result = await this.userRepository.deleteUser(user_id,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("user_delete", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Get('role-getall')
  @ApiOperation({ summary: 'SP: Role_getAll', description: '' })
  @UseGuards(AuthGuard)
  async role_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.userRepository.getAllRoles();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("role_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}
