import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { UnitMasterRepository } from '../repository/unitMaster.repository';
import { UnitInsertDto, UnitUpdateDto } from '../dto/unit.dto';

@ApiTags('Unit-master-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class UnitMasterController {

  constructor(
    private readonly UnitMasterRepository: UnitMasterRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('unit-getall')
  @ApiOperation({ summary: 'SP: UnitMaster_getAll', description: '' })
  @UseGuards(AuthGuard)
  async unit_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.UnitMasterRepository.getAllUnit();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("unit_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('unit-master-insert')
  @ApiOperation({ summary: 'SP: UnitMaster_insert', description: '' })
  @UseGuards(AuthGuard)
  async unit_insert(@Res() res: Response ,@Body() UnitInsertDto:UnitInsertDto,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID || 0;
      const result = await this.UnitMasterRepository.insertUnit(UnitInsertDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_insert", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('unit-update')
  @ApiOperation({ summary: 'SP: UnitMaster_update', description: '' })
  @UseGuards(AuthGuard)
  async unit_update(@Body() UnitUpdateDto:UnitUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.UnitMasterRepository.updateUnit(UnitUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Delete('unit-delete/:UnitMasterid')
  @ApiOperation({ summary: 'SP: UnitMaster_delete', description: '' })
  @UseGuards(AuthGuard)
  async unit_delete(@Param('UnitMasterid') UnitMasterid: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID;
      const result = await this.UnitMasterRepository.deleteUnit(UnitMasterid,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("unit_delete", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}
