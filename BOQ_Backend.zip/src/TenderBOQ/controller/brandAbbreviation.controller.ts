import { Controller, Post, Body, Get, Param, Delete, Res, Req, HttpStatus, Put, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { BadRequest, ServerError, Success } from '../helper/apiStatusCode'; // Assuming these are status codes
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '../middlewares/auth.guard';
import { LoggerService } from '../utils/logger.service';
import { BrandAbbreviationRepository } from '../repository/brandAbbreviation.repository';
import { BrandAbbreviationInsert, BrandAbbreviationUpdateDto } from '../dto/brandAbbreviation.dto';

@ApiTags('Brand-abbreviation-controller')
@ApiBearerAuth('jwt')
@Controller('/api/')
export class BrandAbbreviationController {

  constructor(
    private readonly BrandAbbreviationRepository: BrandAbbreviationRepository,
    private readonly loggerService: LoggerService,
    ) {}

  @Get('brand-abbreviation-getall')
  @ApiOperation({ summary: 'SP: BrandMasterAbbreviation_getAll', description: '' })
  @UseGuards(AuthGuard)
  async brand_abbreviation_getall(@Res() res: Response, @Req() req: Request) {
    try {
      const data = await this.BrandAbbreviationRepository.getAllBrandAbbreviation();
      return res.status(data.StatusCode).json(data);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_getall", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Post('brand-abbreviation-insert')
  @ApiOperation({ summary: 'SP: BrandMasterAbbreviation_insert', description: '' })
  @UseGuards(AuthGuard)
  async brand_abbreviation_insert(@Res() res: Response ,@Body() BrandAbbreviationInsert:BrandAbbreviationInsert,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID || 0;
      const result = await this.BrandAbbreviationRepository.insertBrandAbbreviation(BrandAbbreviationInsert,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_insert", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Put('brand-abbreviation-update')
  @ApiOperation({ summary: 'SP: BrandMasterAbbreviation_update', description: '' })
  @UseGuards(AuthGuard)
  async brand_abbreviation_update(@Body() BrandAbbreviationUpdateDto:BrandAbbreviationUpdateDto,@Res() res: Response,@Req() req: Request) {
    try {
      const userId = req.user?.result?.UserID
      const result = await this.BrandAbbreviationRepository.updateBrandAbbreviation(BrandAbbreviationUpdateDto,userId);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_update", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }

  @Delete('brand-abbreviation-delete/:BrandMasterAbbreviationid')
  @ApiOperation({ summary: 'SP: BrandMasterAbbreviation_delete', description: '' })
  @UseGuards(AuthGuard)
  async brand_abbreviation_delete(@Param('BrandMasterAbbreviationid') BrandMasterAbbreviationid: number, @Req() req: Request,@Res() res: Response) {
    try {
      const modifyBy = req.user?.result?.UserID;
      const result = await this.BrandAbbreviationRepository.deleteBrandAbbreviation(BrandMasterAbbreviationid,modifyBy);
      return res.status(result?.StatusCode).json(result);
    } catch (error) {
      this.loggerService.error("brand_abbreviation_delete", error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json(ApiResponse(ServerError, error.toString(), false, [], 0, false));
    }
  }
}
