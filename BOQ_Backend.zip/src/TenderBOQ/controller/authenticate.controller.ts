import { Controller, Post, Body, Get, Req, Res, UseGuards } from '@nestjs/common';
import { Response, Request } from 'express';
import { ApiResponse } from '../helper/apiResponse.middleware';
import { AuthenticateLoginDto } from '../dto/authenticate.dto';
import { AuthRepository } from '../repository/authenticate.Repository';
import { OK, ValidationError } from '../helper/apiStatusCode';
import { MessageHelper } from '../helper/messageHelper';
import { AuthGuard } from '../middlewares/auth.guard'; // Import the AuthGuard
import { ApiTags,ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { LoggerService } from '../utils/logger.service';

@ApiTags('Authenticate-controller')
@ApiBearerAuth('jwt')
@Controller('/api/authenticate/')
export class loginController {
  constructor(
    private readonly authRepository: AuthRepository,
    private readonly messageHelper: MessageHelper,
    private readonly loggerService: LoggerService,
  ) {}

  @Post('login')
  @ApiOperation({ summary: 'SP: Login', description: 'This endpoint allows users to log in by providing valid credentials.' })
  async login(@Res() res: Response, @Body() authenticateLoginDto: AuthenticateLoginDto,@Req() req: Request) {
    try {
      const getResponse = await this.authRepository.loginRepository(authenticateLoginDto);
      this.loggerService.info("login",getResponse);
      return res.status(getResponse.StatusCode).json(getResponse);
    } catch (err: any) {
      this.loggerService.error("login",err);
      console.log(err, 'Error in login method');
      return res
        .status(500)
        .json(ApiResponse(500, err.toString(), false, [], 0, false));
    }
  }

  @Get('checkToken')
  @UseGuards(AuthGuard) // Apply the AuthGuard to the route
  async checkToken(@Req() req: Request, @Res() res: Response) {
    const token = req.user; // Extract the token from the request object
     
    if (token) {
      const resData = ApiResponse(OK, 'Verified successfully', true, token, 1, true);
      return res.status(OK).json(resData);
    } else {
      return res.status(ValidationError).json(ApiResponse(ValidationError, 'Access denied! Unauthorized user', false, [], 0, false));
    }
  }
}
