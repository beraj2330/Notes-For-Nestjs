// src/helpers/apiStatusCode.ts

export const Success = 200;
export const OK = 200;
export const PermanentRedirect = 301;
export const TemporaryRedirect = 302;
export const NotModified = 304;
export const BadRequest = 400;
export const UnauthorizedError = 401;
export const Forbidden = 403;
export const NotFound = 404;
export const MethodNotAllowed = 405;
export const NotAcceptable = 406;
export const Conflict = 409;
export const ValidationError = 422;
export const TooManyRequests = 429;
export const ServerError = 500;
export const ServiceUnavailable = 503;
