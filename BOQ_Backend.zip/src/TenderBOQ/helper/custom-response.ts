// custom-response.ts
export interface CustomResponse {
    apiResponse: (
      responseStatus: number,
      message: string,
      responseSuccess: boolean,
      data: any[],
      totalRecord: number,
      isAuthFailure: boolean
    ) => void;
  }
  