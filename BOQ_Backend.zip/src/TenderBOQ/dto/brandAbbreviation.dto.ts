import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class BrandAbbreviationInsert {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"UnitMasterid must be string"})
  BrandMasterid: number;

  @ApiProperty()
  @IsString({message:"CreatedBy must be number"})
  Abbreviation: string;
}

export class BrandAbbreviationUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  BrandMasterAbbreviationid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  BrandMasterid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  Abbreviation: string;
}

export class BrandDeleteDto {
  @ApiProperty()
  @IsNumber()
  BrandMasterAbbreviationid: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  ModifiedBy?: number;
}