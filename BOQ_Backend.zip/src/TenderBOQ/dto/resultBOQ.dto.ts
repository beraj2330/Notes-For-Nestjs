import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty, IsArray, ValidateNested, ArrayMinSize } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
export class itemBOQUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"BoqItemId must be number"})
  BoqItemId: number;

  @ApiProperty()
  @IsString({message:"ItemDescription must be string"})
  ItemDescription: string;

  @ApiProperty()
  @IsString({message:"ItemCode must be string"})
  ItemCode: string;

  @ApiProperty()
  @IsNumber({},{message:"Quantity must be number"})
  Quantity: number;

  @ApiProperty()
  @IsString({message:"EstimatedRate must be string"})
  EstimatedRate: string;

  @ApiProperty()
  @IsString({message:"Model must be string"})
  Model: string;

  @ApiProperty()
  @IsString({message:"Model must be string"})
  Unit: string;

  @ApiProperty()
  @IsString({message:"Model must be string"})
  Specification: string;

  @ApiProperty()
  @IsString()
  AdditionalValue1: string;

  @ApiProperty()
  @IsString()
  AdditionalValue2: string;

  @ApiProperty()
  @IsString()
  AdditionalValue3: string;

  @ApiProperty()
  @IsString()
  AdditionalValue4: string;

  @ApiProperty()
  @IsString()
  AdditionalValue5: string;

  @ApiProperty()
  @IsString()
  AdditionalValue6: string;

  @ApiProperty()
  @IsString()
  AdditionalValue7: string;

  @ApiProperty()
  @IsString()
  AdditionalValue8: string;

  @ApiProperty()
  @IsString()
  AdditionalValue9: string;

  @ApiProperty()
  @IsString()
  AdditionalValue10: string;
}

class ResultBOQUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"BoqItemsDetailsId must be number"})
  BoqItemsDetailsId: number;

  @ApiProperty()
  @IsString({message:"BidderName must be string"})
  BidderName: string;

  @ApiProperty()
  @IsNumber({},{message:"Unitprice must be string"})
  UnitPrice: number;

  @ApiProperty()
  @IsNumber({},{message:"Brand must be number"})
  Brand: string;

  @ApiProperty()
  @IsNumber({},{message:"TotalAmount must be string"})
  TotalAmount: number;

  @ApiProperty()
  @IsString({message:"GST must be string"})
  GST: string;

  @ApiProperty()
  @IsString({message:"Unit must be string"})
  Unit: string;

  @ApiProperty()
  @IsString({message:"ExciseDuty must be string"})
  ExciseDuty: string;

  @ApiProperty()
  @IsNumber({},{message:"FreightChargres must be string"})
  FreightChargres: number;
}

export class ResultBOQUpdateArrayDto {
  @ApiProperty({ type: [ResultBOQUpdateDto] })
  @IsArray()
  @ValidateNested({ each: false })
  @Type(() => ResultBOQUpdateDto)
  @ArrayMinSize(1, { message: 'At least one BOQ update is required' })
  data: ResultBOQUpdateDto[];
}

export class resultBOQHoldDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  BoqItemId: number;

  @ApiProperty()
  @IsString({message:"comments must be string"})
  comments: string;
}

export class getExelDataDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  filepath: string;

  @ApiProperty()
  @IsString({message:"itemDescription must be string"})
  itemDescription: string;
}

export class resultSearchDto {
  @ApiProperty()
  @IsString({message:"TenderResultId must be string"})
  TenderResultId: string;

  @ApiProperty()
  @IsString({message:"TenderNumber must be string"})
  TenderNumber: string;

  @ApiProperty()
  @IsString({message:"OrganizationId must be string"})
  OrganizationId: string;

  @ApiProperty()
  @IsString({message:"CreatedDateTo must be string"})
  CreatedDateTo: string;

  @ApiProperty()
  @IsString({message:"CreatedDateFrom must be string"})
  CreatedDateFrom: string;

  @ApiProperty()
  @IsString({message:"AssignBy must be string"})
  AssignBy: string;

  @ApiProperty()
  @IsBoolean()
  OnHold: boolean;

}