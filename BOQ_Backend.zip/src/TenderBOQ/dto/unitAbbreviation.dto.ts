import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class UnitAbbreviation {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"UnitMasterid must be string"})
  UnitMasterid: number;

  @ApiProperty()
  @IsString({message:"Abbreviation must be number"})
  Abbreviation: string;
}

export class UnitAbbreviationUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  UnitMasterAbbreviationid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  UnitMasterid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  Abbreviation: string;
}

export class UnitDeleteDto {
  @ApiProperty()
  @IsNumber()
  UnitMasterid: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  ModifiedBy?: number;
}