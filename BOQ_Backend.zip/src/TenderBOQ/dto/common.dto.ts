import { IsNumber, IsOptional, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class FilterDto {
  @ApiProperty()
  @IsOptional()
  @IsNumber()
  id?: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  parentids?: string;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  noofrecords?: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  pageNo?: number;

  @ApiProperty()
  @IsString()
  @IsOptional()
  name?: string;
}
