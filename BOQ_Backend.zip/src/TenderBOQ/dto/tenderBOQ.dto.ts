import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class tenderBOQUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"Boqid must be number"})
  Boqid:number;

  @ApiProperty()
  @IsString()
  ItemDescription: string;

  @ApiProperty()
  @IsString()
  ItemCode: string;

  @ApiProperty()
  @IsString()
  Quantity: string;

  @ApiProperty()
  @IsNumber()
  Unit: number;

  @ApiProperty()
  @IsNumber()
  Brand: number;

  @ApiProperty()
  @IsString()
  EstimatedRate: string;

  @ApiProperty()
  @IsString()
  TotalAmount: string;

  @ApiProperty()
  @IsString()
  AdditionalValue1: string;

  @ApiProperty()
  @IsString()
  AdditionalValue2: string;

  @ApiProperty()
  @IsString()
  AdditionalValue3: string;

  @ApiProperty()
  @IsString()
  AdditionalValue4: string;

  @ApiProperty()
  @IsString()
  AdditionalValue5: string;

  @ApiProperty()
  @IsString()
  AdditionalValue6: string;

  @ApiProperty()
  @IsString()
  AdditionalValue7: string;

  @ApiProperty()
  @IsString()
  AdditionalValue8: string;

  @ApiProperty()
  @IsString()
  AdditionalValue9: string;

  @ApiProperty()
  @IsString()
  AdditionalValue10: string;

  @ApiProperty()
  @IsString()
  Model: string;

  @ApiProperty()
  @IsString()
  Specification: string;

  @ApiProperty()
  @IsNumber()
  ModifyBy: number;

}
export class tenderBOQHoldDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"Boqid must be number"})
  Boqid: number;

  @ApiProperty()
  @IsNumber({},{message:"OnHoldBy must be number"})
  OnHoldby: number;

  @ApiProperty()
  @IsString({message:"Comments must be string"})
  Comments: string;
}

export class tenderSearchDto {
  @ApiProperty()
  @IsString({message:"Tenderid must be string"})
  Tenderid: string;

  @ApiProperty()
  @IsString({message:"TenderNumber must be string"})
  TenderNumber: string;

  @ApiProperty()
  @IsString({message:"OrganizationId must be string"})
  OrganizationId: string;

  @ApiProperty()
  @IsString({message:"CreatedDateTo must be string"})
  CreatedDateTo: string;

  @ApiProperty()
  @IsString({message:"CreatedDateFrom must be string"})
  CreatedDateFrom: string;

  @ApiProperty()
  @IsString({message:"RequirementWorkBrief must be string"})
  RequirementWorkBrief: string;

  @ApiProperty()
  @IsString({message:"AssignBy must be string"})
  AssignBy: string;

  @ApiProperty()
  @IsBoolean()
  OnHold: boolean;

}