import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class BrandInsertDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString({message:"BrandName must be string"})
  BrandName: string;

  @ApiProperty()
  @IsNumber({},{message:"CreatedBy must be number"})
  CreatedBy: number;
}

export class BrandUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  BrandMasterid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  BrandName: string;
}

export class BrandDeleteDto {
  @ApiProperty()
  @IsNumber()
  UnitMasterid: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  ModifiedBy?: number;
}