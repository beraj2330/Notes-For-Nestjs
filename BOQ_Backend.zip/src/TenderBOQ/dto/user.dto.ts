import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class UserInsertDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString({message:"userName must be string"})
  UserName: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString({message:"Password must be valid"})
  Password: string;

  @ApiProperty()
  @IsString({message:"Mobile must be string"})
  Mobile: string;

  @ApiProperty()
  @IsString({message:"Address  must be string"})
  Address: string;

  @ApiProperty()
  @IsBoolean()
  UserTypeID: boolean;

  @ApiProperty()
  @IsNotEmpty()
  @IsNumber({},{message:"RoleId must be number"})
  RoleId: number;

  @ApiProperty()
  @IsNumber({},{message:"CreatedBy must be number"})
  CreatedBy: number;
}


export class UserUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  UserID: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  UserName: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  Password: string;

  @ApiProperty()
  @IsBoolean()
  @IsOptional()
  Mobile: string;

  @ApiProperty()
  @IsString()
  Address: string;

  @ApiProperty()
  @IsBoolean()
  UserTypeID: boolean;

  @ApiProperty()
  @IsNumber()
  RoleId: number;
  
  @ApiProperty()
  @IsNumber()
  ModifiedBy: number;
}




export class UserDeleteDto {
  @ApiProperty()
  @IsNumber()
  cat_id: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  user_id?: number;
}