import { IsEmail, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class AuthenticateLoginDto {
  @ApiProperty()
  @IsNotEmpty()
  UserName: string;

  @ApiProperty()
  @IsNotEmpty()
  Password: string;
}