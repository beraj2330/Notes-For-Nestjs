import { IsString, IsBoolean, IsOptional, IsNumber, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
export class UnitInsertDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString({message:"UnitName must be string"})
  UnitName: string;

  @ApiProperty()
  @IsNumber({},{message:"CreatedBy must be number"})
  CreatedBy: number;

}

export class UnitUpdateDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  UnitMasterid: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  UnitName: string;
}

export class UnitDeleteDto {
  @ApiProperty()
  @IsNumber()
  UnitMasterid: number;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  ModifiedBy?: number;
}