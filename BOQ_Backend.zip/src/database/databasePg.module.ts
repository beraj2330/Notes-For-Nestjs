import { Module } from '@nestjs/common';
import { Pool } from 'pg';

@Module({
  providers: [
    {
      provide: 'PG_POOL',
      useFactory: async () => {
        const pool = new Pool({
          host: process.env.DB_PG_HOST,
          database: process.env.DB_PG_DATABASE,
          user: process.env.DB_PG_USERNAME,
          password: process.env.DB_PG_PASSWORD,
          port: parseInt(process.env.DB_PG_PORT, 10),
          max: parseInt(process.env.DB_MAX_POOL_SIZE, 10) || 100,
          idleTimeoutMillis: 30000,
        });
        try {
          await pool.connect();
          console.log('PG Database connected successfully'); // Log success message
          return pool;
        } catch (error) {
          console.error('Error connecting to PostgreSQL:', error);
          throw error;
        }
      },
    },
  ],
  exports: [],
})
export class DatabasePgModule {}
