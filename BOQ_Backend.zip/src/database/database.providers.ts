import { Injectable, Inject } from '@nestjs/common';
import * as mssql from 'mssql';
import { ApiResponse } from '../TenderBOQ/helper/apiResponse.middleware';

// Define the parameter type
interface SqlParameter {
  name: string;
  type: mssql.ISqlTypeFactoryWithLength;
  value: any;
}

@Injectable()
export class DbConfig {
  private pool: mssql.ConnectionPool;

  constructor(@Inject('MSSQL_POOL') pool: mssql.ConnectionPool) {
    this.pool = pool;
  }

  async callSPWithOutParam(
    spName: string,
    inputParams: SqlParameter[] = [],
    outputParams: SqlParameter[] = []
  ): Promise<any> {
    try {
      const request = new mssql.Request(this.pool);

      // Set input parameters
      inputParams.forEach((param) => {
        request.input(param.name, param.type, param.value);
      });

      // Set output parameters
      outputParams.forEach((param) => {
        request.output(param.name, param.type, param.value);
      });

      const result = await request.execute(spName);

      // Determine responseData based on the type of result
      let responseData: any;
      if (outputParams.length > 0) {
        responseData = result.output;
      } else if (result.recordset) {
        responseData = result.recordset;
      } else {
        responseData = [];
      }

      // Ensure responseData is an array for consistent response format
      const responseArray = Array.isArray(responseData) ? responseData : [responseData];

      return ApiResponse(
        200,
        'Success',
        true,
        responseArray,
        responseArray.length,
        true
      );
    } catch (error) {
      console.log(error, 'error');
      return ApiResponse(500, error.message || 'Internal Server Error', false, [], 0, false);
    }
  }
}


